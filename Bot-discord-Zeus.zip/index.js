// Archivo de entrada principal del bot
// Este archivo simplemente importa y ejecuta el bot desde src/index.js

import './src/index.js';
