import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType } from 'discord.js';

export default {
    data: new SlashCommandBuilder()
        .setName('ticket-setup')
        .setDescription('Configura el sistema de tickets del servidor')
        .addChannelOption(option =>
            option.setName('canal')
                .setDescription('Canal donde se enviará el panel de tickets')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true))
        .addStringOption(option =>
            option.setName('titulo')
                .setDescription('Título del panel de tickets')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('descripcion')
                .setDescription('Descripción del panel de tickets')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const channel = interaction.options.getChannel('canal');
        const titulo = interaction.options.getString('titulo') || '🎫 Sistema de Tickets';
        const descripcion = interaction.options.getString('descripcion') || 
            'Haz clic en el botón de abajo para crear un ticket de soporte.\n\n' +
            '**¿Cuándo crear un ticket?**\n' +
            '• Reportar un problema\n' +
            '• Solicitar ayuda del staff\n' +
            '• Hacer una sugerencia\n' +
            '• Reportar a un usuario\n\n' +
            '**Reglas importantes:**\n' +
            '• Solo puedes tener un ticket abierto a la vez\n' +
            '• Sé respetuoso y claro en tu consulta\n' +
            '• El staff responderá lo antes posible';

        await interaction.deferReply({ ephemeral: true });

        try {
            // Crear embed del panel de tickets
            const ticketEmbed = new EmbedBuilder()
                .setTitle(titulo)
                .setDescription(descripcion)
                .setColor('#0099ff')
                .addFields(
                    { 
                        name: '📋 Información', 
                        value: 'Los tickets son privados y solo tú y el staff pueden verlos.',
                        inline: true 
                    },
                    { 
                        name: '⏰ Tiempo de respuesta', 
                        value: 'Normalmente respondemos en menos de 24 horas.',
                        inline: true 
                    }
                )
                .setFooter({ 
                    text: `${interaction.guild.name} • Sistema de Tickets`,
                    iconURL: interaction.guild.iconURL()
                })
                .setTimestamp();

            // Botón para crear ticket
            const ticketButton = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('ticket_create')
                        .setLabel('Crear Ticket')
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji('🎫')
                );

            // Enviar panel al canal especificado
            const ticketPanel = await channel.send({
                embeds: [ticketEmbed],
                components: [ticketButton]
            });

            // Crear o buscar categoría de tickets
            let ticketCategory = interaction.guild.channels.cache.find(
                ch => ch.name.toLowerCase().includes('tickets') && 
                      ch.type === ChannelType.GuildCategory
            );

            if (!ticketCategory) {
                ticketCategory = await interaction.guild.channels.create({
                    name: '🎫 TICKETS',
                    type: ChannelType.GuildCategory,
                    permissionOverwrites: [
                        {
                            id: interaction.guild.roles.everyone.id,
                            deny: [PermissionFlagsBits.ViewChannel]
                        },
                        {
                            id: interaction.guild.members.me.id,
                            allow: [
                                PermissionFlagsBits.ViewChannel,
                                PermissionFlagsBits.ManageChannels,
                                PermissionFlagsBits.SendMessages
                            ]
                        }
                    ]
                });

                // Añadir permisos para roles de staff
                const staffRoles = interaction.guild.roles.cache.filter(role => 
                    role.name.toLowerCase().includes('staff') ||
                    role.name.toLowerCase().includes('mod') ||
                    role.name.toLowerCase().includes('admin') ||
                    role.permissions.has(PermissionFlagsBits.ManageMessages)
                );

                for (const role of staffRoles.values()) {
                    await ticketCategory.permissionOverwrites.create(role.id, {
                        ViewChannel: true,
                        SendMessages: true,
                        ReadMessageHistory: true,
                        ManageChannels: true
                    });
                }
            }

            // Crear canal de logs de tickets si no existe
            let ticketLogs = interaction.guild.channels.cache.find(
                ch => ch.name === 'ticket-logs'
            );

            if (!ticketLogs) {
                ticketLogs = await interaction.guild.channels.create({
                    name: 'ticket-logs',
                    type: ChannelType.GuildText,
                    parent: ticketCategory.id,
                    permissionOverwrites: [
                        {
                            id: interaction.guild.roles.everyone.id,
                            deny: [PermissionFlagsBits.ViewChannel]
                        },
                        {
                            id: interaction.guild.members.me.id,
                            allow: [
                                PermissionFlagsBits.ViewChannel,
                                PermissionFlagsBits.SendMessages
                            ]
                        }
                    ]
                });

                // Añadir permisos de logs para staff
                const staffRoles = interaction.guild.roles.cache.filter(role => 
                    role.permissions.has(PermissionFlagsBits.ManageMessages)
                );

                for (const role of staffRoles.values()) {
                    await ticketLogs.permissionOverwrites.create(role.id, {
                        ViewChannel: true,
                        ReadMessageHistory: true
                    });
                }
            }

            // Guardar configuración en base de datos (opcional)
            try {
                // Aquí se guardaría la configuración del sistema de tickets
                console.log('Configuración de tickets guardada:', {
                    guildId: interaction.guild.id,
                    panelChannelId: channel.id,
                    panelMessageId: ticketPanel.id,
                    categoryId: ticketCategory.id,
                    logsChannelId: ticketLogs.id,
                    setupBy: interaction.user.id,
                    setupAt: new Date()
                });
            } catch (error) {
                console.error('Error guardando configuración de tickets:', error);
            }

            // Respuesta de confirmación
            const successEmbed = new EmbedBuilder()
                .setTitle('✅ Sistema de Tickets Configurado')
                .setDescription('El sistema de tickets ha sido configurado exitosamente.')
                .setColor('#00ff00')
                .addFields(
                    { name: '📍 Panel enviado a', value: `${channel}`, inline: true },
                    { name: '📁 Categoría creada', value: `${ticketCategory}`, inline: true },
                    { name: '📋 Logs en', value: `${ticketLogs}`, inline: true }
                )
                .setFooter({ text: 'Los usuarios ya pueden crear tickets usando el botón.' })
                .setTimestamp();

            await interaction.editReply({
                embeds: [successEmbed]
            });

            // Log en el canal de logs
            const logEmbed = new EmbedBuilder()
                .setTitle('🔧 Sistema de Tickets Configurado')
                .setDescription(`El sistema de tickets ha sido configurado por ${interaction.user}.`)
                .addFields(
                    { name: 'Canal del Panel', value: `${channel}` },
                    { name: 'Configurado por', value: `${interaction.user}` }
                )
                .setColor('#0099ff')
                .setTimestamp();

            await ticketLogs.send({ embeds: [logEmbed] });

        } catch (error) {
            console.error('Error configurando sistema de tickets:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setTitle('❌ Error')
                .setDescription('Ocurrió un error al configurar el sistema de tickets.')
                .addFields(
                    { name: 'Error', value: error.message || 'Error desconocido' }
                )
                .setColor('#ff0000')
                .setTimestamp();

            await interaction.editReply({
                embeds: [errorEmbed]
            });
        }
    }
};
